import calendar

class Gr_Calendar():
    def __init__(self,year):
        if type(year) is int:
            self.year = calendar.calendar(year).replace(6*" "+str(year), "Ημερολόγιο "+str(year))
            self.lexikon = {'April': 'Απρίλιος', 'June': 'Ιούνιος', 'July': 'Ιούλιος', 'January': 'Ιανουάριος',
                            'March': 'Μάρτιος', 'November':'Νοέμβριος', 'February':'Φεβρουάριος','December':'Δεκέμβριος',
                            'September': 'Σεπτέμβριος','May': 'Μάιος', 'October': 'Οκτώβριος', 'August': 'Αύγουστος'}
            en_days = "Mo Tu We Th Fr Sa Su"
            gr_days = "Δε Τρ Τε Πε Πα Σα Κυ"
            self.year = self.year.replace(en_days, gr_days)
            for month in self.lexikon:
                self.replace_center(month, self.lexikon[month])
        else: self.year = ""
        
    def replace_center(self, m_en, m_gr):
        l_en = len(m_en)
        l_gr = len(m_gr)
        l_dif = l_gr - l_en # Greek months longer than English in all cases
        leading_spaces = l_dif//2
        trailing_spaces = l_dif - leading_spaces
        to_replace = leading_spaces * " " + m_en + trailing_spaces * " "
        if to_replace not in self.year: # case of month at end of line, so no trailing spaces
            to_replace = leading_spaces * " " + m_en
        self.year = self.year.replace(to_replace, m_gr)

    def __str__(self):
        return "\n"+self.year

def main():
    gr_calendar = Gr_Calendar(2016)
    print(gr_calendar)
    
if __name__ == '__main__':
    main()
