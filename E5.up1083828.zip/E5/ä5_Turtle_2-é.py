import turtle as t
import random

def square(length):
    for i in range(4):
        t.forward(length)
        t.left(90)

def triangle(length):
    for i in range(3):
        t.forward(length)
        t.left(120)
    
def circle(length):
    t.circle(length/2)

def hexagon(length):
    t.forward(length/1.7) 
    for i in range(5):
        t.right(60) 
        t.forward(length/1.7) 

def trapezium(length):
    length += 50
    t.forward(2*length/3)
    t.left(120)
    t.forward((2*length)/(3*(3**0.5)))
    t.left(60)
    t.forward(length/3)
    t.left(60)
    t.forward((2*length)/(3*(3**0.5)))
    t.left(120)

def star(length):
    for i in range(5):
        t.forward(length)
        t.right(144)

def shapedrawer(x, y):
    R = random.randrange(0, 255)
    B = random.randrange(0, 255)
    G = random.randrange(0, 255)
    size = random.randrange(20,70)
    t.penup()
    # Set the position of the turtle to the clicked location.
    t.setpos(x, y)
    t.pendown()
    t.begin_fill()
    if x <= 400 and y<=400: 
        t.color((R,G,B))
        trapezium(size)

    elif 400 <= x <=800 and y<=400:  # Left third.
        t.color((R,G,B))
        circle(size)
        
    elif 800 <= x <= 1200 and y<=400:
        t.color((R,G,B))
        hexagon(size)

    elif x <= 400 and y<=800: 
        t.color((R,G,B))
        square(size)

    elif 400 < x <= 800 and y<=800: 
        t.color((R,G,B))
        triangle(size)

    else:  
        t.color((R,G,B))
        star(size)

    t.end_fill()


def main():
    # Set window to be 300 by 200 with the point (0, 0) as the
    # lower left corner and (300, 200) as the upper right corner.
    t.setup(1200, 800)
    t.screensize(1200, 800)
    t.setworldcoordinates(0, 0, 1200, 800)
    t.ht()
    t.speed('fastest')
    t.colormode(255)
    # Draw two vertical lines to divide the window into thirds.
    t.penup()
    t.setpos(400, 0)  # First line.
    t.pendown()
    t.setpos(400, 800)
    t.penup()
    t.setpos(800, 0)  # Second line.
    t.pendown()
    t.setpos(800, 800)
    # Draw one horizontal line to split the window
    t.penup()
    t.setpos(0,400)  # First line.
    t.pendown()
    t.setpos(1200, 400)
    t.onscreenclick(shapedrawer)
    t.title('Βαγγέλης Δρακονταειδής-up1083828')
    t.mainloop()
    


if __name__ == '__main__':
    main()
