import turtle as t
import random


def square(length):
    for i in range(4):
        t.forward(length)
        t.left(90)

def triangle(length):
    for i in range(3):
        t.forward(length)
        t.left(120)
    
def circle(length):
    t.circle(length/2)

def shapedrawer(x, y):
    R = random.randrange(0, 255)
    B = random.randrange(0, 255)
    G = random.randrange(0, 255)
    size = random.randrange(20,120)
    t.penup()
    # Set the position of the turtle to the clicked location.
    t.setpos(x, y)
    t.pendown()
    t.begin_fill()
    if x <= 400:  # Left third.
        t.color((R,G,B))
        circle(size)
    elif 400 < x <= 800:  # Middle third.
        t.color((R,G,B))
        triangle(size)
    else:  # Right third.
        t.color((R,G,B))
        square(size)
    t.end_fill()


def main():
    # Set window to be 300 by 200 with the point (0, 0) as the
    # lower left corner and (300, 200) as the upper right corner.
    t.setup(1200, 800)
    t.screensize(1200, 800)
    t.setworldcoordinates(0, 0, 1200, 800)
    t.ht()
    t.speed('fastest')
    t.colormode(255)
    # Draw two vertical lines to divide the window into thirds.
    t.penup()
    t.setpos(400, 0)  # First line.
    t.pendown()
    t.setpos(400, 800)
    t.penup()
    t.setpos(800, 0)  # Second line.
    t.pendown()
    t.setpos(800, 800)

    t.onscreenclick(shapedrawer)
    t.mainloop()


if __name__ == '__main__':
    main()
