import turtle as t


def square(length):
    for i in range(4):
        t.forward(length)
        t.left(90)

def triangle(length):
    for i in range(3):
        t.forward(length)
        t.left(120)
    
def circle(length):
    t.circle(length/2)

def shapedrawer(x, y):
    t.penup()
    # Set the position of the turtle to the clicked location.
    t.setpos(x, y)
    t.pendown()
    t.begin_fill()
    if x <= 100:  # Left third.
        t.color("green")
        circle(10)
    elif 100 < x <= 200:  # Middle third.
        t.color("red")
        triangle(10)
    else:  # Right third.
        t.color("blue")
        square(10)
    t.end_fill()


def main():
    # Set window to be 300 by 200 with the point (0, 0) as the
    # lower left corner and (300, 200) as the upper right corner.
    t.setup(300, 200)
    t.screensize(300, 200)
    t.setworldcoordinates(0, 0, 300, 200)
    t.ht()
    t.speed('fastest')
    t.colormode(255)
    # Draw two vertical lines to divide the window into thirds.
    t.penup()
    t.setpos(100, 0)  # First line.
    t.pendown()
    t.setpos(100, 200)
    t.penup()
    t.setpos(200, 0)  # Second line.
    t.pendown()
    t.setpos(200, 200)

    t.onscreenclick(shapedrawer)
    t.mainloop()


if __name__ == '__main__':
    main()
