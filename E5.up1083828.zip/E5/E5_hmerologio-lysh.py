import tkinter
import random
import datetime
import grcalendar


class App():
    def __init__(self, root):
        self.root = root
        self.large_font = "Consolas 20"  # άλλαξε το μορφότυπο για τα πλήκτρα
        self.medium_font = "Consolas 12"  # άλλαξε το μορφότυπο για το
        # Hμερολόγιο
        self.colors = self.load_colors()
        self.widgets()

        self.yr = datetime.datetime.now().year
        self.show_year(self.yr)
        # πρόσθεσε εντολές για να δείχνει το τρέχον έτος
        # με χρήση της datetime.datetime.now()

    def widgets(self):
        f1 = tkinter.Frame(self.root)
        f1.pack()

        self.entryText = tkinter.StringVar()

        button_previous = tkinter.Button(f1, font=self.large_font,
                                         text="  <<  ",
                                         command=self.previous_year)
        button_previous.pack(side='left', expand=True)

        label = tkinter.Label(f1, font=self.large_font, text=" Έτος: ")
        label.pack(side='left', expand=True)

        self.year_box = tkinter.Entry(f1, font=self.large_font,
                                      textvariable=self.entryText, width=5)
        self.year_box.pack(side='left', expand=True)
        self.year_box.bind("<Return>", self.this_year)

        button = tkinter.Button(f1, font=self.large_font, text="   ΟΚ   ")
        button.pack(side='left', expand=True)
        button.bind('<Button-1>', self.this_year)

        button_next = tkinter.Button(f1, font=self.large_font, text="   >>   ",
                                     command=self.next_year)
        button_next.pack(side='left', expand=True, fill='both')

        f2 = tkinter.Frame(self.root)
        f2.pack(expand=True, fill='both')

        self.text = tkinter.Text(f2, font=self.medium_font)
        self.scroll = tkinter.Scrollbar(f2, command=self.text.yview)
        self.scroll.pack(side='right', fill='both')
        self.text.configure(yscrollcommand=self.scroll.set)
        self.text.pack(side='left', fill='both', padx=20, pady=20)

    def load_colors(self):
        color_list = []
        try:
            for color in open('light_colors.txt','r'):
                color = color.replace('\n','')
                color_list.append(color)
        except:
            pass
        finally:
            return color_list

    def previous_year(self):
        self.yr = self.yr -1
        self.text.delete('1.0', 'end')
        calendar = grcalendar.Gr_Calendar(self.yr)
        cal_color = random.choice(self.colors)
        self.text.configure(bg=str(cal_color))
        self.text.insert('end',calendar)

        # συμπληρώστε κώδικα για αλλαγή έτους

    def next_year(self):
        self.yr = self.yr +1
        self.text.delete('1.0', 'end')
        calendar = grcalendar.Gr_Calendar(self.yr)
        cal_color = random.choice(self.colors)
        calendar = grcalendar.Gr_Calendar(self.yr)
        self.text.configure(bg=str(cal_color))
        self.text.insert('end',calendar)

        # συμπληρώστε κώδικα για αλλαγή έτους

    def this_year(self, event):
        year = self.year_box.get()
        try:
            year = int(year)
            self.yr = year
            self.show_year(year)
        except:
            pass

    def show_year(self, year):
        self.year_box.delete(0,'end')
        self.text.delete('1.0','end')
        cal_color = random.choice(self.colors)
        calendar = grcalendar.Gr_Calendar(year)
        self.text.insert('end',calendar)
        self.text.configure(bg=str(cal_color))
        # με χρήση της grcalendar, φόρτωσε το ημερολόγιο
        # και όρισε το χρώμα του υποβάθρου του

def main():
    root = tkinter.Tk()
    root.title("Ελληνικό Ημερολόγιο")
    root.wm_geometry("800x800-50+50")
    App(root)
    root.mainloop()


if __name__ == '__main__':
    main()
