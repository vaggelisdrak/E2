import turtle as t
import random


def box(l):
    R = random.randrange(0, 255)
    B = random.randrange(0, 255)
    G = random.randrange(0, 255)
    if l > 100:
        t.color((R,G,B))
    else:
        t.color((R,G,B))
    t.pendown()
    t.begin_fill()
    for i in range(4):
        t.forward(l)
        t.left(90)
    t.end_fill()


def manyBoxes(num):
    for j in range(num):
        x = random.randint(-300, 250)
        y = random.randint(-300, 250)
        l = random.randint(50, 150)
        t.penup()
        t.goto(x, y)
        box(l)


def main():
    t.speed("fastest")
    t.ht()
    t.setup(800, 800)
    t.title('E5_1_square_examples')
    t.colormode(255)
    manyBoxes(100)
    t.mainloop()


if __name__ == '__main__':
    main()
